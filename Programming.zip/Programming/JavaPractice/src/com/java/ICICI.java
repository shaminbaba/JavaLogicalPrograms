package com.java;

public class ICICI extends RBI {
	
	
	public double rateOfInterest(double interest){
	
		return new ICICI().RateOfInterest(interest);
      
	}

}
