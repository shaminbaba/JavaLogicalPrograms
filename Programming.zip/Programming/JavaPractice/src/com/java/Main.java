package com.java;

public class Main {
	
	public static void main(String[] args) {
		System.out.println("hello world");
		
		ICICI obj=new ICICI();
		System.out.println(obj.rateOfInterest(5));
	}

}
