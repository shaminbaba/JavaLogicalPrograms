package com.java;

public class RBI {
	
	
	double interest;
	
	public double RateOfInterest(double interest) {
		
		
		return this.interest=interest;
		
	}

}
