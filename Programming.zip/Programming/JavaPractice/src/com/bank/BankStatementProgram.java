package com.bank;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class BankStatementProgram {
	
	public static void fileReader(String cardnumber) throws IOException {
		
		FileReader bankaccountfr=null;
		FileReader banktransactionfr=null;
		File bankaccount;
		File banktransaction;
		Map<String,String> mapbankaccountfr;
		Map<String, String> mapbanktransactionfr;
		String accardnumber="";
		
		try {
			bankaccount=new File("C:\\Softwares\\bankaccount.txt");
			banktransaction=new File("C:\\Softwares\\banktransaction.txt");
			
			bankaccountfr=new FileReader(bankaccount);
			banktransactionfr =new FileReader(banktransaction);
			
			int i;
			
			String bankaccountfrDetails = "";
			String banktransactionDetails = "";
			
			while((i = bankaccountfr.read()) != -1) {
				bankaccountfrDetails =bankaccountfrDetails +(char)i;
			}
			
			while((i = banktransactionfr.read()) != -1) {
				banktransactionDetails =banktransactionDetails +(char)i;
			}
			
			String[] strbankaccountfr = bankaccountfrDetails.split(":");
			
			mapbankaccountfr =new LinkedHashMap<String,String>();
			mapbanktransactionfr=new LinkedHashMap<String,String>();
			
			
			String strbankaccount = "";
			
			for(String s: strbankaccountfr) {
				
				String str1 ="";
				String[] str =s.split(",");
				for(String s1 :str) {
					
					if(s1.trim().toLowerCase().equalsIgnoreCase(cardnumber)) {
						str1 =s1.toLowerCase();
						
						strbankaccount =strbankaccount + s;
					}
					
					
				}
				if(mapbankaccountfr.containsKey(cardnumber)) {
					
					mapbankaccountfr.remove(cardnumber);
					mapbankaccountfr.put(cardnumber, strbankaccount);
				}else {
					mapbankaccountfr.put(cardnumber, strbankaccount);
					
				}
				
			}
				String strbant = "";
				
				String[] strbanktransactionfr = banktransactionDetails.split(":");
				String strbankacc=mapbankaccountfr.get(cardnumber);
				String[] strbankaccarr=strbankacc.split(",");
				
				for(int i1=0;i1<strbankaccarr.length;i1++) {
					if(i1==4) {
						accardnumber=strbankaccarr[4];
					}
				}
			
				for(String sbtfr : strbanktransactionfr) {
					
					String str1="";
					String[] str = sbtfr.split(",");
					for(String s1 :str) {
						if(s1.trim().toLowerCase().equalsIgnoreCase(accardnumber)) {
							str1=s1.toLowerCase();
							strbant = strbant +sbtfr;
						}
					}
					
					if(mapbanktransactionfr.containsKey(accardnumber)) {
						mapbanktransactionfr.remove(accardnumber);
						mapbanktransactionfr.put(accardnumber, strbant);
					}else {
						mapbanktransactionfr.put(accardnumber, strbant);
					}
				}
				
			String str3= accardnumber;
			mapbankaccountfr.forEach((key, value)->{
				mapbanktransactionfr.forEach((key1,value1) -> {
					
					String str1;
					
					String str2;
					
					
					if(key.trim().equalsIgnoreCase(cardnumber)  || key.trim().equalsIgnoreCase(str3)) {
						
						str1 =mapbankaccountfr.get(cardnumber);
						str2 =mapbanktransactionfr.get(str3);
						
						System.out.println(str1+str2);
								
					}else {
						System.out.println("please give valid one");
					}
					
				});
			});
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(bankaccountfr!= null) {
				bankaccountfr.close();
			} else if(bankaccountfr!= null) {
				banktransactionfr.close();
			}
			
		}
	}

	public static void main(String[] args) throws IOException {
		InputStreamReader r=new InputStreamReader(System.in);
		
		BufferedReader br=new BufferedReader(r);
		
		
		System.out.println("Enter Name");
		
		String cardnumber= br.readLine();
		
		System.out.println("============================================================");
		
		System.out.println("name"+" "+"age"+" "+"gender"+" "+"Bank"+" "+"card number"+" "+"credit limit");
		
		
		fileReader(cardnumber);
		
		
	}
	
}
