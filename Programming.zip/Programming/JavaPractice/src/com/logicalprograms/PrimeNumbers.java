package com.logicalprograms;

public class PrimeNumbers {
	
	
	
	

}
