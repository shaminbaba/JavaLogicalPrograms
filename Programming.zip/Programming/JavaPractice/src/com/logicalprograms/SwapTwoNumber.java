package com.logicalprograms;

public class SwapTwoNumber {
	
	
	
	public static void main(String[] args) {
		
	
	
	int a=10;
	int b=20;
	int c;
	System.out.println("before swaping with thrid varible a:"+a+"----b:"+b);
	c=b-a;
	
	b=c;
	a=a+b;
	System.out.println("before swaping with thrid varible a:"+a+"------b:"+b);
	
	b=a-b;
	a=b+b;
	
	System.out.println("before swaping without thrid varible a:"+a+"------b:"+b);
	
	}
	

}
